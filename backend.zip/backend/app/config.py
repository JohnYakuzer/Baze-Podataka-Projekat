class Config:
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://korisnik:lozinka@localhost/avio_kompanija'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
