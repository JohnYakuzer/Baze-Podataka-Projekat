from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

# Veza M:N između korisnika i rola
korisnik_role = db.Table('korisnik_role',
    db.Column('korisnik_id', db.Integer, db.ForeignKey('korisnici.korisnik_id')),
    db.Column('role_id', db.Integer, db.ForeignKey('role.role_id'))
)

class Role(db.Model):
    __tablename__ = 'role'
    role_id = db.Column(db.Integer, primary_key=True)
    naziv = db.Column(db.String(50), unique=True)

class Korisnik(db.Model):
    __tablename__ = 'korisnici'
    korisnik_id = db.Column(db.Integer, primary_key=True)
    ime = db.Column(db.String(50))
    prezime = db.Column(db.String(50))
    email = db.Column(db.String(100), unique=True)
    lozinka_hash = db.Column(db.String(100))
    broj_telefona = db.Column(db.String(15), nullable=True)

    # Relacija korisnik-role
    role = db.relationship('Role', secondary=korisnik_role, backref='korisnici')

    def set_lozinku(self, lozinka):
        self.lozinka_hash = generate_password_hash(lozinka)

    def provjeri_lozinku(self, lozinka):
        return check_password_hash(self.lozinka_hash, lozinka)

    def ima_rolu(self, naziv_role):
        return any(role.naziv == naziv_role for role in self.role)

class Let(db.Model):
    __tablename__ = 'letovi'
    let_id = db.Column(db.Integer, primary_key=True)
    polazni_aerodrom = db.Column(db.String(100))
    odredisni_aerodrom = db.Column(db.String(100))
    vrijeme_polaska = db.Column(db.String(100))
    vrijeme_dolaska = db.Column(db.String(100))
    cijena = db.Column(db.Float)
    avio_kompanija = db.Column(db.String(100))
    dostupna_sjedišta = db.Column(db.Integer)
    broj_terminala = db.Column(db.String(10))
    broj_izlaza = db.Column(db.String(10))
    trajanje_leta = db.Column(db.String(50))
    dodatne_informacije = db.Column(db.String(200))

class Rezervacija(db.Model):
    __tablename__ = 'rezervacije'
    rezervacija_id = db.Column(db.Integer, primary_key=True)
    korisnik_id = db.Column(db.Integer, db.ForeignKey('korisnici.korisnik_id'))
    let_id = db.Column(db.Integer, db.ForeignKey('letovi.let_id'))
    datum_rezervacije = db.Column(db.String(50))
    status = db.Column(db.String(50), default="potvrđeno")
    rezervisana_sjedišta = db.Column(db.Integer)
    ukupna_cijena = db.Column(db.Float)
