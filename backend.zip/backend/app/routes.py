from flask import request, jsonify, abort
from .models import Korisnik, Let, Rezervacija, db
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

def register_routes(app):

    @app.route('/registracija', methods=['POST'])
    def registracija():
        data = request.get_json()
        ime = data.get('ime')
        prezime = data.get('prezime')
        email = data.get('email')
        lozinka = data.get('lozinka')

        if Korisnik.query.filter_by(email=email).first():
            return jsonify({'message': 'Email je već zauzet'}), 400

        korisnik = Korisnik(
            ime=ime,
            prezime=prezime,
            email=email
        )
        korisnik.set_lozinku(lozinka)

        db.session.add(korisnik)
        db.session.commit()

        return jsonify({'message': 'Korisnik je uspješno registriran'}), 201

    @app.route('/login', methods=['POST'])
    def login():
        data = request.get_json()
        email = data.get('email')
        lozinka = data.get('lozinka')

        korisnik = Korisnik.query.filter_by(email=email).first()

        if korisnik and korisnik.provjeri_lozinku(lozinka):
            return jsonify({'message': 'Uspješna prijava!', 'korisnik_id': korisnik.korisnik_id}), 200
        else:
            return jsonify({'message': 'Pogrešan email ili lozinka'}), 400

    @app.route('/letovi', methods=['GET'])
    def get_letovi():
        letovi = Let.query.all()
        return jsonify([{
            'let_id': let.let_id,
            'polazni_aerodrom': let.polazni_aerodrom,
            'odredisni_aerodrom': let.odredisni_aerodrom,
            'vrijeme_polaska': let.vrijeme_polaska,
            'vrijeme_dolaska': let.vrijeme_dolaska,
            'cijena': let.cijena,
            'dostupna_sjedišta': let.dostupna_sjedišta,
            'broj_terminala': let.broj_terminala,
            'broj_izlaza': let.broj_izlaza,
            'trajanje_leta': let.trajanje_leta,
            'dodatne_informacije': let.dodatne_informacije,
        } for let in letovi])

    @app.route('/rezervacija', methods=['POST'])
    def rezervacija():
        data = request.get_json()
        korisnik_id = data.get('korisnik_id')
        let_id = data.get('let_id')
        rezervisana_sjedišta = data.get('rezervisana_sjedišta')

        let = Let.query.get(let_id)
        if let.dostupna_sjedišta < rezervisana_sjedišta:
            return jsonify({'message': 'Nema dovoljno dostupnih sjedišta'}), 400

        ukupna_cijena = let.cijena * rezervisana_sjedišta
        nova_rezervacija = Rezervacija(
            korisnik_id=korisnik_id,
            let_id=let_id,
            datum_rezervacije='2025-05-29',
            rezervisana_sjedišta=rezervisana_sjedišta,
            ukupna_cijena=ukupna_cijena
        )

        let.dostupna_sjedišta -= rezervisana_sjedišta
        db.session.add(nova_rezervacija)
        db.session.commit()

        return jsonify({'message': 'Rezervacija uspješno napravljena', 'ukupna_cijena': ukupna_cijena})

    @app.route('/rezervacije', methods=['GET'])
    def get_rezervacije():
        korisnik_id = request.args.get('korisnik_id')
        rezervacije = Rezervacija.query.filter_by(korisnik_id=korisnik_id).all()
        return jsonify([{
            'rezervacija_id': r.rezervacija_id,
            'let_id': r.let_id,
            'datum_rezervacije': r.datum_rezervacije,
            'rezervisana_sjedišta': r.rezervisana_sjedišta,
            'ukupna_cijena': r.ukupna_cijena,
            'status': r.status,
        } for r in rezervacije])

    @app.route('/')
    def index():
        return jsonify({'message': 'Dobrodošli na API za avio kompaniju!'})

    def admin_required(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            korisnik_id = request.headers.get('X-Korisnik-Id')
            if not korisnik_id:
                return jsonify({'message': 'Autorizacija je potrebna'}), 401
            korisnik = Korisnik.query.get(korisnik_id)
            if not korisnik or not korisnik.ima_rolu('admin'):
                return jsonify({'message': 'Nemaš dozvolu'}), 403
            return f(*args, **kwargs)
        return decorated_function

    @app.route('/letovi/<int:let_id>', methods=['PUT'])
    @admin_required
    def izmeni_let(let_id):
        let = Let.query.get(let_id)
        if not let:
            return jsonify({'message': 'Let nije pronađen'}), 404

        data = request.get_json()
        for polje in ['polazni_aerodrom', 'odredisni_aerodrom', 'vrijeme_polaska', 'vrijeme_dolaska', 
                      'cijena', 'avio_kompanija', 'dostupna_sjedišta', 'broj_terminala', 
                      'broj_izlaza', 'trajanje_leta', 'dodatne_informacije']:
            if polje in data:
                setattr(let, polje, data[polje])

        db.session.commit()
        return jsonify({'message': 'Let je uspješno ažuriran'})

